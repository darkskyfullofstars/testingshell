# win10script

## Quick Install

```PowerShell
powershell -nop -c "iex(New-Object Net.WebClient).DownloadString('https://git.io/JJdmk')"
```

## Forked and tweaked

Original: https://github.com/ChrisTitusTech/win10script

Modified to fix my needs.
